rm -f assignment2.zip
zip -r assignment2.zip *.py ./chr_en_data ./sanity_check_en_es_data ./outputs